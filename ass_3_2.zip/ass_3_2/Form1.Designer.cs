﻿namespace ass_3_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.cmbsemester = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbmscit = new System.Windows.Forms.RadioButton();
            this.rbbscit = new System.Windows.Forms.RadioButton();
            this.rbmca = new System.Windows.Forms.RadioButton();
            this.rbbca = new System.Windows.Forms.RadioButton();
            this.txtaddress = new System.Windows.Forms.TextBox();
            this.btnpreview = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(139, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Student Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "Student Name : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 173);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "Semester :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(36, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Mobile No. : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(36, 255);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "Address : ";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(119, 69);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(162, 20);
            this.txtname.TabIndex = 1;
            // 
            // txtmobile
            // 
            this.txtmobile.AcceptsTab = true;
            this.txtmobile.Location = new System.Drawing.Point(119, 207);
            this.txtmobile.MaxLength = 10;
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(162, 20);
            this.txtmobile.TabIndex = 2;
            // 
            // cmbsemester
            // 
            this.cmbsemester.FormattingEnabled = true;
            this.cmbsemester.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.cmbsemester.Location = new System.Drawing.Point(119, 169);
            this.cmbsemester.Name = "cmbsemester";
            this.cmbsemester.Size = new System.Drawing.Size(162, 21);
            this.cmbsemester.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbmscit);
            this.groupBox1.Controls.Add(this.rbbscit);
            this.groupBox1.Controls.Add(this.rbmca);
            this.groupBox1.Controls.Add(this.rbbca);
            this.groupBox1.Location = new System.Drawing.Point(41, 107);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(284, 46);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Branch";
            // 
            // rbmscit
            // 
            this.rbmscit.AutoSize = true;
            this.rbmscit.Location = new System.Drawing.Point(216, 19);
            this.rbmscit.Name = "rbmscit";
            this.rbmscit.Size = new System.Drawing.Size(63, 17);
            this.rbmscit.TabIndex = 0;
            this.rbmscit.TabStop = true;
            this.rbmscit.Text = "M.Sc.IT";
            this.rbmscit.UseVisualStyleBackColor = true;
            this.rbmscit.CheckedChanged += new System.EventHandler(this.rbmscit_CheckedChanged);
            // 
            // rbbscit
            // 
            this.rbbscit.AutoSize = true;
            this.rbbscit.Location = new System.Drawing.Point(149, 19);
            this.rbbscit.Name = "rbbscit";
            this.rbbscit.Size = new System.Drawing.Size(61, 17);
            this.rbbscit.TabIndex = 0;
            this.rbbscit.TabStop = true;
            this.rbbscit.Text = "B.Sc.IT";
            this.rbbscit.UseVisualStyleBackColor = true;
            this.rbbscit.CheckedChanged += new System.EventHandler(this.rbbscit_CheckedChanged);
            // 
            // rbmca
            // 
            this.rbmca.AutoSize = true;
            this.rbmca.Location = new System.Drawing.Point(78, 19);
            this.rbmca.Name = "rbmca";
            this.rbmca.Size = new System.Drawing.Size(48, 17);
            this.rbmca.TabIndex = 0;
            this.rbmca.TabStop = true;
            this.rbmca.Text = "MCA";
            this.rbmca.UseVisualStyleBackColor = true;
            this.rbmca.CheckedChanged += new System.EventHandler(this.rbmca_CheckedChanged);
            // 
            // rbbca
            // 
            this.rbbca.AutoSize = true;
            this.rbbca.Location = new System.Drawing.Point(6, 19);
            this.rbbca.Name = "rbbca";
            this.rbbca.Size = new System.Drawing.Size(46, 17);
            this.rbbca.TabIndex = 0;
            this.rbbca.TabStop = true;
            this.rbbca.Text = "BCA";
            this.rbbca.UseVisualStyleBackColor = true;
            this.rbbca.CheckedChanged += new System.EventHandler(this.rbbca_CheckedChanged);
            // 
            // txtaddress
            // 
            this.txtaddress.Location = new System.Drawing.Point(119, 251);
            this.txtaddress.Multiline = true;
            this.txtaddress.Name = "txtaddress";
            this.txtaddress.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtaddress.Size = new System.Drawing.Size(162, 52);
            this.txtaddress.TabIndex = 2;
            this.txtaddress.WordWrap = false;
            // 
            // btnpreview
            // 
            this.btnpreview.Location = new System.Drawing.Point(143, 334);
            this.btnpreview.Name = "btnpreview";
            this.btnpreview.Size = new System.Drawing.Size(75, 23);
            this.btnpreview.TabIndex = 5;
            this.btnpreview.Text = "Preview";
            this.btnpreview.UseVisualStyleBackColor = true;
            this.btnpreview.Click += new System.EventHandler(this.btnpreview_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 369);
            this.Controls.Add(this.btnpreview);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmbsemester);
            this.Controls.Add(this.txtaddress);
            this.Controls.Add(this.txtmobile);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Student Details";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.ComboBox cmbsemester;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbmscit;
        private System.Windows.Forms.RadioButton rbbscit;
        private System.Windows.Forms.RadioButton rbmca;
        private System.Windows.Forms.RadioButton rbbca;
        private System.Windows.Forms.TextBox txtaddress;
        private System.Windows.Forms.Button btnpreview;
    }
}

