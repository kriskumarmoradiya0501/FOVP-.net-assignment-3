﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ass_3_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rbbca_CheckedChanged(object sender, EventArgs e)
        {
            if(cmbsemester.Items.Count == 4)
            {
                cmbsemester.Items.Add("5");
                cmbsemester.Items.Add("6");
            }
        }

        private void rbmca_CheckedChanged(object sender, EventArgs e)
        {
            if (cmbsemester.Items.Count == 6)
            {
                cmbsemester.Items.RemoveAt(4);
                cmbsemester.Items.RemoveAt(4);
            }
            

        }

        private void rbmscit_CheckedChanged(object sender, EventArgs e)
        {
            if(cmbsemester.Items.Count == 6) {
                cmbsemester.Items.RemoveAt(4);
                cmbsemester.Items.RemoveAt(4);
            }
            
        }

        private void rbbscit_CheckedChanged(object sender, EventArgs e)
        {
            if (cmbsemester.Items.Count == 4)
            {
                cmbsemester.Items.Add("5");
                cmbsemester.Items.Add("6");
            }
        }

        private void btnpreview_Click(object sender, EventArgs e)
        {
            String name = "", branch = "", semester = "", mobile = "", add = "";
            name += txtname.Text;
            if (rbbca.Checked)
            {
                branch += rbbca.Text;
            }
            if (rbbscit.Checked) {
                branch += rbbscit.Text;
            }
            if(rbmca.Checked)
            {
                branch += rbmca.Text;
            }
            if (rbmscit.Checked) { 
                branch = rbmscit.Text;
            }
            semester = cmbsemester.Text;
            mobile=txtmobile.Text;
            add = txtaddress.Text;
            MessageBox.Show("Name : " + name + "\nBranch : " + branch +
                "\nSemester : "+semester+"\nMobile : "+mobile+"Address : "+add);
        }
    }
}
