﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ass_3_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalculate_Click(object sender, EventArgs e)
        {
            float redius=0.0f,width=0.0f,height=0.0f;
            redius += float.Parse(txtreduis.Text);
            width += float.Parse(txtwidth.Text);
            height += float.Parse(txtheight.Text);
            if (rbcircle.Checked)
            {
                MessageBox.Show("Circule area = " + (3.14 * redius * redius));
            }
            if (rbractangle.Checked)
            {
                MessageBox.Show("Ranctangle Area = " + (width * height));
            }
            if (rbsquare.Checked)
            {
                MessageBox.Show("Square area = " + (width * width));
            }
        }

        private void rbcircle_CheckedChanged(object sender, EventArgs e)
        {
            txtheight.Enabled = false;
            txtwidth.Enabled = false;
            txtreduis.Enabled = true;
            txtheight.Text = "0";
            txtwidth.Text = "0";
        }

        private void rbsquare_CheckedChanged(object sender, EventArgs e)
        {
            txtheight.Enabled = false;
            txtwidth.Enabled = true;
            txtreduis.Enabled = false;
            txtheight.Text = "0";
            txtreduis.Text = "0";
        }

        private void rbractangle_CheckedChanged(object sender, EventArgs e)
        {
            txtheight.Enabled = true;
            txtwidth.Enabled = true;
            txtreduis.Enabled = false;
            txtreduis.Text= "0";
        }
    }
}
