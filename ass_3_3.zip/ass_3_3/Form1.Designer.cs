﻿namespace ass_3_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbcircle = new System.Windows.Forms.RadioButton();
            this.rbsquare = new System.Windows.Forms.RadioButton();
            this.rbractangle = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtreduis = new System.Windows.Forms.TextBox();
            this.txtwidth = new System.Windows.Forms.TextBox();
            this.txtheight = new System.Windows.Forms.TextBox();
            this.btncalculate = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbractangle);
            this.groupBox1.Controls.Add(this.rbsquare);
            this.groupBox1.Controls.Add(this.rbcircle);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(142, 144);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose Options";
            // 
            // rbcircle
            // 
            this.rbcircle.AutoSize = true;
            this.rbcircle.Location = new System.Drawing.Point(26, 38);
            this.rbcircle.Name = "rbcircle";
            this.rbcircle.Size = new System.Drawing.Size(51, 17);
            this.rbcircle.TabIndex = 0;
            this.rbcircle.TabStop = true;
            this.rbcircle.Text = "Circle";
            this.rbcircle.UseVisualStyleBackColor = true;
            this.rbcircle.CheckedChanged += new System.EventHandler(this.rbcircle_CheckedChanged);
            // 
            // rbsquare
            // 
            this.rbsquare.AutoSize = true;
            this.rbsquare.Location = new System.Drawing.Point(26, 107);
            this.rbsquare.Name = "rbsquare";
            this.rbsquare.Size = new System.Drawing.Size(59, 17);
            this.rbsquare.TabIndex = 0;
            this.rbsquare.TabStop = true;
            this.rbsquare.Text = "Square";
            this.rbsquare.UseVisualStyleBackColor = true;
            this.rbsquare.CheckedChanged += new System.EventHandler(this.rbsquare_CheckedChanged);
            // 
            // rbractangle
            // 
            this.rbractangle.AutoSize = true;
            this.rbractangle.Location = new System.Drawing.Point(26, 72);
            this.rbractangle.Name = "rbractangle";
            this.rbractangle.Size = new System.Drawing.Size(74, 17);
            this.rbractangle.TabIndex = 0;
            this.rbractangle.TabStop = true;
            this.rbractangle.Text = "Rectangle";
            this.rbractangle.UseVisualStyleBackColor = true;
            this.rbractangle.CheckedChanged += new System.EventHandler(this.rbractangle_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(184, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Redius : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(184, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Width :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(184, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Height : ";
            // 
            // txtreduis
            // 
            this.txtreduis.Location = new System.Drawing.Point(253, 29);
            this.txtreduis.Name = "txtreduis";
            this.txtreduis.Size = new System.Drawing.Size(100, 20);
            this.txtreduis.TabIndex = 2;
            this.txtreduis.Text = "0";
            // 
            // txtwidth
            // 
            this.txtwidth.Location = new System.Drawing.Point(253, 66);
            this.txtwidth.Name = "txtwidth";
            this.txtwidth.Size = new System.Drawing.Size(100, 20);
            this.txtwidth.TabIndex = 2;
            this.txtwidth.Text = "0";
            // 
            // txtheight
            // 
            this.txtheight.Location = new System.Drawing.Point(253, 116);
            this.txtheight.Name = "txtheight";
            this.txtheight.Size = new System.Drawing.Size(100, 20);
            this.txtheight.TabIndex = 2;
            this.txtheight.Text = "0";
            // 
            // btncalculate
            // 
            this.btncalculate.Location = new System.Drawing.Point(157, 170);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(75, 23);
            this.btncalculate.TabIndex = 3;
            this.btncalculate.Text = "Calculate";
            this.btncalculate.UseVisualStyleBackColor = true;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.ClientSize = new System.Drawing.Size(403, 205);
            this.Controls.Add(this.btncalculate);
            this.Controls.Add(this.txtheight);
            this.Controls.Add(this.txtwidth);
            this.Controls.Add(this.txtreduis);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Area calculation";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbractangle;
        private System.Windows.Forms.RadioButton rbsquare;
        private System.Windows.Forms.RadioButton rbcircle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtreduis;
        private System.Windows.Forms.TextBox txtwidth;
        private System.Windows.Forms.TextBox txtheight;
        private System.Windows.Forms.Button btncalculate;
    }
}

