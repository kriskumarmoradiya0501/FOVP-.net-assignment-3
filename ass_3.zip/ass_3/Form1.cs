﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ass_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnpreview_Click(object sender, EventArgs e)
        {
            String name="", desi="", type="";
            int basic=0, da=0, totalsal=0;
            name += txtname.Text;
            desi += cmbdesi.Text;
            if(rbcontact.Checked ) { type += rbcontact.Text; }
            else if(rbper.Checked ) { type += rbper.Text; }
            basic += int.Parse(txtbasic.Text);
            da += int.Parse(txtda.Text);
            totalsal += int.Parse(txttotalsal.Text);
            MessageBox.Show("Name : "+ name+ "\nDesignation : "+desi+
                "\nEmployee Type : "+type+
                "\nBasic Salary : "+basic+
                "\nDA : "+da+
                "\nTotal Salary : "+totalsal);
       
        }

        private void cmbdesi_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbdesi.SelectedIndex == 0 || cmbdesi.SelectedIndex == 1)
            {
                rbper.Checked = true;
                groupBox1.Enabled = false;
            }
            else
            {
                groupBox1.Enabled = true;
            }
        }


        private void rbper_CheckedChanged(object sender, EventArgs e)
        {
            if (rbper.Checked)
            {

                txtbasic.Enabled = true;
                txtda.Enabled = true;
                txttotalsal.Enabled = false;
            }
        }

        private void rbcontact_CheckedChanged(object sender, EventArgs e)
        {
            if (rbcontact.Checked)
            {
                txtbasic.Enabled = false;
                txtda.Enabled = false;
                txttotalsal.Enabled = true;
                txtbasic.Text = "0";
                txtda.Text = "0";
                txttotalsal.Text = "0";
            }
        }
        private void txtbasic_Leave(object sender, EventArgs e)
        {
            txttotalsal.Text = int.Parse(txtbasic.Text) + int.Parse(txtda.Text) + "";
        }
        private void txtda_Leave(object sender, EventArgs e)
        {
            txttotalsal.Text = int.Parse(txtbasic.Text) + int.Parse(txtda.Text) + "";
        }

    }
}
