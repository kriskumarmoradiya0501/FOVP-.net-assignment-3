﻿namespace ass_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtda = new System.Windows.Forms.TextBox();
            this.txtbasic = new System.Windows.Forms.TextBox();
            this.txttotalsal = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.cmbdesi = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbcontact = new System.Windows.Forms.RadioButton();
            this.rbper = new System.Windows.Forms.RadioButton();
            this.btnpreview = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee Details";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Employee Name : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Designation";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 200);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Basic Pay :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "DA : ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 281);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 0;
            this.label6.Text = "Total Salary : ";
            // 
            // txtda
            // 
            this.txtda.Location = new System.Drawing.Point(108, 236);
            this.txtda.Name = "txtda";
            this.txtda.Size = new System.Drawing.Size(100, 20);
            this.txtda.TabIndex = 1;
            this.txtda.Text = "0";
            this.txtda.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtda.Leave += new System.EventHandler(this.txtda_Leave);
            // 
            // txtbasic
            // 
            this.txtbasic.Location = new System.Drawing.Point(108, 193);
            this.txtbasic.Name = "txtbasic";
            this.txtbasic.Size = new System.Drawing.Size(100, 20);
            this.txtbasic.TabIndex = 1;
            this.txtbasic.Text = "0";
            this.txtbasic.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtbasic.Leave += new System.EventHandler(this.txtbasic_Leave);
            // 
            // txttotalsal
            // 
            this.txttotalsal.Location = new System.Drawing.Point(108, 274);
            this.txttotalsal.Name = "txttotalsal";
            this.txttotalsal.Size = new System.Drawing.Size(100, 20);
            this.txttotalsal.TabIndex = 1;
            this.txttotalsal.Text = "0";
            this.txttotalsal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(108, 74);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 20);
            this.txtname.TabIndex = 1;
            // 
            // cmbdesi
            // 
            this.cmbdesi.FormattingEnabled = true;
            this.cmbdesi.Items.AddRange(new object[] {
            "Dean",
            "Principal",
            "Associate Professor",
            "Assistant Professor"});
            this.cmbdesi.Location = new System.Drawing.Point(108, 111);
            this.cmbdesi.Name = "cmbdesi";
            this.cmbdesi.Size = new System.Drawing.Size(121, 21);
            this.cmbdesi.TabIndex = 2;
            this.cmbdesi.SelectedIndexChanged += new System.EventHandler(this.cmbdesi_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbcontact);
            this.groupBox1.Controls.Add(this.rbper);
            this.groupBox1.Location = new System.Drawing.Point(15, 138);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(249, 47);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Type";
            // 
            // rbcontact
            // 
            this.rbcontact.AutoSize = true;
            this.rbcontact.Location = new System.Drawing.Point(141, 20);
            this.rbcontact.Name = "rbcontact";
            this.rbcontact.Size = new System.Drawing.Size(79, 17);
            this.rbcontact.TabIndex = 0;
            this.rbcontact.TabStop = true;
            this.rbcontact.Text = "On Contact";
            this.rbcontact.UseVisualStyleBackColor = true;
            this.rbcontact.CheckedChanged += new System.EventHandler(this.rbcontact_CheckedChanged);
            // 
            // rbper
            // 
            this.rbper.AutoSize = true;
            this.rbper.Location = new System.Drawing.Point(34, 20);
            this.rbper.Name = "rbper";
            this.rbper.Size = new System.Drawing.Size(76, 17);
            this.rbper.TabIndex = 0;
            this.rbper.TabStop = true;
            this.rbper.Text = "Permanent";
            this.rbper.UseVisualStyleBackColor = true;
            this.rbper.CheckedChanged += new System.EventHandler(this.rbper_CheckedChanged);
            // 
            // btnpreview
            // 
            this.btnpreview.Location = new System.Drawing.Point(124, 327);
            this.btnpreview.Name = "btnpreview";
            this.btnpreview.Size = new System.Drawing.Size(75, 23);
            this.btnpreview.TabIndex = 4;
            this.btnpreview.Text = "Preview";
            this.btnpreview.UseVisualStyleBackColor = true;
            this.btnpreview.Click += new System.EventHandler(this.btnpreview_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(309, 404);
            this.Controls.Add(this.btnpreview);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmbdesi);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txttotalsal);
            this.Controls.Add(this.txtbasic);
            this.Controls.Add(this.txtda);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Employee Details";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtda;
        private System.Windows.Forms.TextBox txtbasic;
        private System.Windows.Forms.TextBox txttotalsal;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.ComboBox cmbdesi;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbcontact;
        private System.Windows.Forms.RadioButton rbper;
        private System.Windows.Forms.Button btnpreview;
    }
}

